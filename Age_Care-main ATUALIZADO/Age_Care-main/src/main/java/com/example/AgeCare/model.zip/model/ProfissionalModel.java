package com.example.AgeCare.model;

import java.util.ArrayList;
import java.util.List;

import com.example.AgeCare.Status.StatusDisponibilidade;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "cuidador")
public class ProfissionalModel extends AuditableModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String email;
    private String senha;
    private String telefone;

    private String formacao;
    private String biografia;
    private String curriculoUrl;

    private double notaMedia;
    private int totalAvaliacoes;
    private int totalAtendimentos;

    @Enumerated(EnumType.STRING)
    private StatusDisponibilidade statusDisponibilidade;

    @OneToMany(mappedBy = "profissional", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<ServicoModel> servicos = new ArrayList<>();

    @OneToMany(mappedBy = "profissional")
    @JsonIgnore
    private List<AgendamentoModel> agendamentos;

    @ManyToMany
    @JoinTable(
        name = "profissional_especializacoes",
        joinColumns = @JoinColumn(name = "profissional_id"),
        inverseJoinColumns = @JoinColumn(name = "especializacao_id")
    )
    private List<EspecialidadeModel> especialidades;

    @OneToMany(mappedBy = "profissional")
    @JsonIgnore
    private List<EnderecoModel> enderecos;
}
